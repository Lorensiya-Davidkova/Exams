package shelter;

import java.util.ArrayList;
import java.util.List;

public class Shelter {
    private List<Animal> data;
    private int capacity;

    public Shelter(int capacity){
        this.data=new ArrayList<>();
        this.setCapacity(capacity);
    }
    public void setCapacity(int capacity){
        this.capacity=capacity;
    }
    public int getCapacity(){
        return this.capacity;
    }
    public List<Animal> getData(){
        return this.data;
    }
    public void add(Animal animal){
        if(this.data.size()<=capacity-1) {
            this.data.add(animal);
        }
    }
    public boolean remove(String name){
        boolean toReturn=false;
        for(Animal animal:this.data){
            if(animal.getName().equals(name)){
                this.data.remove(animal);
                toReturn=true;
                break;
            }
        }
        return toReturn;
    }
    public Animal getAnimal(String name,String caretaker){
        Animal toReturn=null;
        for(Animal animal:this.data){
            if(animal.getName().equals(name) && animal.getCaretaker().equals(caretaker)){
                toReturn=animal;
            }
        }
        return toReturn;
    }
    public Animal getOldestAnimal(){
        Animal toReturn=null;
        int max=this.data.get(0).getAge();
        for(Animal animal:this.data){
            if(animal.getAge()>max){
                max=animal.getAge();
                toReturn=animal;
            }
        }
        return toReturn;
    }
    public int getCount(){
        return this.data.size();
    }
    public String getStatistics(){
        String toReturn="";
        for(Animal animal:this.data){
            toReturn=toReturn+animal.getName()+" "+animal.getCaretaker()+"\n";
        }
        return "The shelter has the following animals:"+"\n"+toReturn;
    }
}
