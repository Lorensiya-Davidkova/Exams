package hotel;

public class Person {
    private String name;
    private int id;
    private int age;
    private String hometown="n/a";

    public Person(String name,int id,int age,String hometown){
        this.setName(name);
        this.setId(id);
        this.setAge(age);
        this.setHometown(hometown);
    }
    public void setName(String name){
        this.name=name;
    }
    public String getName(){
        return this.name;
    }
    public void setId(int id){
        this.id=id;
    }
    public int getId(){
        return this.id;
    }
    public void setAge(int age){
        this.age=age;
    }
    public int getAge(){
        return this.age;
    }
    public void setHometown(String hometown){
        this.hometown=hometown;
    }
    public String getHometown(){
        return this.hometown;
    }

    @Override
    public String toString() {
        return "Person "+this.name+": "+ this.id+ ", Age: "+this.age+", Hometown: "+this.hometown;
    }
}
