package hotel;

import java.util.*;

public class Hotel {
    private String name;
    private int capacity;
    private List<Person> roster;

    public Hotel(String name,int capacity){
        this.setName(name);
        this.setCapacity(capacity);
        this.roster=new ArrayList<>();
    }
    public void setName(String name){
        this.name=name;
    }
    public String getName(){
        return this.name;
    }
    public void setCapacity(int capacity){
        this.capacity=capacity;
    }
    public int getCapacity(){
        return this.capacity;
    }
    public List<Person> getRoster(){
        return this.roster;
    }
    public void add(Person person){
        if(capacity>=this.roster.size()+1){
            roster.add(person);
        }
    }
    public boolean remove(String name){
        boolean toReturn=false;
       for(Person p:this.roster){
           if(p.getName().equals(name)){
               this.roster.remove(p);
               toReturn=true;
               break;
           }
       }
       return toReturn;
    }
    public Person getPerson(String name,String hometown){
        Person toReturn=null;
        for(Person p:this.roster){
            if(p.getName().equals(name) && p.getHometown().equals(hometown)){
                toReturn=p;
            }
        }
        return toReturn;
    }
    public int getCount(){
        return this.roster.size();
    }
    public String getStatistics(){
        String additional="";
        for(Person p:this.roster){
            String current=p.toString()+"\n";
            additional=additional+current;
        }
        return "The people in the hotel "+this.name+" are:\n"+additional;
    }
}
