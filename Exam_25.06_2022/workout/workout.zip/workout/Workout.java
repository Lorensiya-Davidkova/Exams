package workout;

import java.util.ArrayList;
import java.util.List;

public class Workout {
    private List<Exercise> exercises;
    private String type;
    private int exerciseCount;
    public Workout(String type, int exerciseCount){
        this.exercises=new ArrayList<>();
        this.setType(type);
        this.setExerciseCount(exerciseCount);
    }
    public void setType(String type){
        this.type=type;
    }
    public String getType(){
        return this.type;
    }
    public void setExerciseCount(int exerciseCount){
        this.exerciseCount=exerciseCount;
    }
    public int getExerciseCount1(){
        return this.exerciseCount;
    }
    public List<Exercise> getExercises(){
        return this.exercises;
    }
    public void addExercise(Exercise exercise){
        if(this.exercises.size()<=this.getExerciseCount()-1){
            exercises.add(exercise);
        }
    }
    public boolean removeExercise(String name,String muscle){
        boolean toReturn=false;
        for(Exercise exercise:this.exercises){
            if(exercise.getName().equals(name) && exercise.getMuscle().equals(muscle)){
                this.exercises.remove(exercise);
                toReturn=true;
                break;
            }
        }
        return toReturn;
    }

    public Exercise getExercise(String name,String muscle){
        Exercise toReturn=null;
        for(Exercise exercise:this.exercises){
            if(exercise.getName().equals(name) && exercise.getMuscle().equals(muscle)){
                toReturn=exercise;
                break;
            }
        }
        return toReturn;
    }

    public Exercise getMostBurnedCaloriesExercise(){
        Exercise toReturn=null;
        int max=this.exercises.get(0).getBurnedCalories();
        for(Exercise exercise:this.exercises){
            if(exercise.getBurnedCalories()>max){
                max=exercise.getBurnedCalories();
                toReturn=exercise;
            }
        }
        return toReturn;
    }
    public int getExerciseCount(){
        return this.exerciseCount;
    }
    public String getStatistics(){
        String toReturn="";
        toReturn="Workout type: "+this.getType()+"\n";
        for(Exercise exercise:this.exercises){
            toReturn=toReturn+exercise.toString()+"\n";
        }
        return toReturn;
    }
}
